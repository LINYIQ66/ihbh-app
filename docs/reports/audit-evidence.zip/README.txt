Globest Mall offline audit evidence
Commit: 81bba2390ce1a6f917be993762666ea81a396da1

Extract into a fresh directory. Install the TypeScript compiler only:
  npm --prefix work/source/globest-mall-main install --ignore-scripts --no-audit --no-fund
Then run from the extraction root:
  node work/audit-repro.mjs

This runner performs no network requests or production writes. Base44 storage, identity and Stripe verification are mocks. It proves application control-flow defects, not deployed platform access. The included source files are unmodified audit fixtures. Build/lint/typecheck logs were generated using the full original repository and its lockfile, not this minimal fixture package.
