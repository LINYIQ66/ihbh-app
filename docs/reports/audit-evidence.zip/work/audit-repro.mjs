// Offline audit harness: original application functions, mocked platform/storage.
// No network calls, real accounts, credentials, payments, or production writes.
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import ts from './source/globest-mall-main/node_modules/typescript/lib/typescript.js';
const root = path.resolve('work/source/globest-mall-main');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
function handler(file, mocks) {
  const source = read(file).replace(/^import .*;\r?\n/gm, '').replace('export default async function', 'async function handler');
  const js = ts.transpileModule(source, {compilerOptions:{target:ts.ScriptTarget.ES2022}}).outputText;
  const context = vm.createContext({Response, Request, URL, URLSearchParams, TextEncoder, crypto, console:{error(){}}, ...mocks});
  return vm.runInContext(js + '\nhandler', context);
}
const request = body => new Request('https://offline.invalid/', {method:'POST', body:JSON.stringify(body)});
const results = [];
function ledger(seed = 100) {
  const rows = [{id:'seed',user_id:'u',amount:seed,type:'seed'}];
  let failReward = false;
  const matches = (row, query) => Object.entries(query).every(([k,v]) => typeof v === 'object' ? true : row[k] === v);
  const L = {
    count:async q=>rows.filter(r=>matches(r,q)).length,
    aggregate:async ({query})=>({rows:[{sum_amount:rows.filter(r=>matches(r,query)).reduce((n,r)=>n+r.amount,0)}]}),
    filter:async q=>({items:rows.filter(r=>matches(r,q))}),
    create:async data=>{if(failReward && data.type==='purchase') throw new Error('injected storage failure'); const row={id:crypto.randomUUID(),...data};rows.push(row);return row;},
    delete:async id=>{const i=rows.findIndex(r=>r.id===id);if(i>=0)rows.splice(i,1);}
  };
  const client = {auth:{me:async()=>({id:'u',email:'u@example.invalid'})},asServiceRole:{entities:{PointsLedger:L}}};
  return {rows,fn:handler('base44/functions/pointsLedger/entry.ts',{createClientFromRequest:()=>client}),balance:()=>rows.reduce((n,r)=>n+r.amount,0),failReward:()=>{failReward=true;}};
}
{
  const x=ledger(20);const res=await x.fn(request({action:'spend',points:1,sgd:1000000,ref:'offline-test'}));
  assert.equal(res.status,200);assert.equal(x.balance(),500019);
  results.push({test:'Client-controlled spending reward',initial:20,pointsSpent:1,claimedSgd:1000000,finalBalance:x.balance(),confirmed:true});
}
{
  const x=ledger(0);
  for(const key of ['read-does-not-exist-a','read-does-not-exist-b']) assert.equal((await x.fn(request({action:'earn',key}))).status,200);
  assert.equal(x.balance(),20);results.push({test:'Unknown article keys rewarded',finalBalance:x.balance(),confirmed:true});
}
{
  const x=ledger(100);
  const res=await Promise.all(['a','b'].map(ref=>x.fn(request({action:'spend',points:80,sgd:0,ref}))));
  assert.deepEqual(res.map(r=>r.status),[200,200]);assert.equal(x.balance(),-60);
  results.push({test:'Concurrent spending exceeds balance',initial:100,spends:[80,80],statuses:res.map(r=>r.status),finalBalance:x.balance(),confirmed:true});
}
{
  const x=ledger(100);x.failReward();const body={action:'spend',points:10,sgd:20,ref:'same-request'};
  const first=await x.fn(request(body));const second=await x.fn(request(body));
  assert.equal(first.status,500);assert.equal(second.status,409);assert.equal(x.balance(),90);
  results.push({test:'Partial debit cannot complete on retry',statuses:[first.status,second.status],finalBalance:x.balance(),confirmed:true});
}
{
  const source=read('src/components/globest/ExperienceProvider.jsx');
  const spend=source.split('\n').find(s=>s.includes('const spendHbh ='));
  const record=source.split('\n').find(s=>s.includes('const recordPurchase ='));
  const ctx=vm.createContext({state:{hbh:100,orders:[]},authed:true,SHOP_REWARD:0.5,crypto,notify(){},t:x=>x,server:async()=>({ok:false,reason:'insufficient'}),pick:x=>x});
  ctx.update=fn=>{ctx.state=fn(ctx.state);};
  vm.runInContext(spend+'\n'+record+"\nif (spendHbh(80,8)) recordPurchase([{id:'product'}],8);",ctx);
  assert.equal(ctx.state.orders[0].paid,true);
  results.push({test:'Frontend marks purchase paid without backend success',paid:ctx.state.orders[0].paid,confirmed:true});
}
{
  let event;const profiles=[];
  const client={asServiceRole:{entities:{MemberProfile:{filter:async q=>profiles.filter(p=>p.email===q.email),create:async p=>profiles.push({id:'profile',...p}),update:async(id,p)=>Object.assign(profiles.find(x=>x.id===id),p)}}}};
  class Stripe {webhooks={constructEventAsync:async()=>event};}
  const fn=handler('base44/functions/stripeMembershipWebhook/entry.ts',{Stripe,createClientFromRequest:()=>client,secrets:{get:()=> 'mock-only'}});
  const session=(tier,id,livemode=false)=>({id,livemode,payment_status:'paid',metadata:{membership_tier:tier,membership_fee:1500},customer_details:{email:'u@example.invalid'}});
  const invoke=async s=>{event={id:'evt_'+s.id,type:'checkout.session.completed',data:{object:s}};return fn(new Request('https://offline.invalid/',{method:'POST',headers:{'stripe-signature':'mocked-valid-signature'},body:'{}'}));};
  assert.equal((await invoke(session('prestige','test-prestige'))).status,200);assert.equal(profiles[0].payment_status,'paid');
  results.push({test:'Valid sandbox event grants paid membership',storedTier:profiles[0].tier,paymentStatus:profiles[0].payment_status,confirmed:true});
  await invoke(session('standard','old-standard',true));
  assert.equal(profiles[0].tier,'standard');
  results.push({test:'Older valid membership event overwrites newer tier',tierBefore:'prestige',tierAfter:profiles[0].tier,confirmed:true});
}
{
  const schema=JSON.parse(read('base44/entities/MemberProfile.jsonc'));
  assert.equal(schema.rls,undefined);
  const user=JSON.parse(read('base44/entities/User.jsonc'));
  assert.equal(user.properties.partner_status.rls,undefined);
  results.push({test:'Schema inspection only, not live RLS enforcement',memberProfileRlsAbsent:true,partnerStatusFieldRlsAbsent:true,confirmed:true});
}
{
  const source=read('base44/shared/dealerOverview.ts').replace(/^import .*;\r?\n/gm,'').replace('export async function','async function');
  const overview=vm.runInNewContext(source+'\ndealerOverview',{getAccount:async()=>null,inventory:async()=>[],postedQuery:()=>({}),saleOwner:()=>({})});
  const client={entities:Object.fromEntries(['Earning','Withdrawal','PurchaseOrder','ShipOrder'].map(n=>[n,{aggregate:async()=>({rows:n==='Withdrawal'?[{status:'pending',sum_amount:-1000}]:n==='PurchaseOrder'?[{status:'pending',sum_balance_used:-1000,count:1}]:[]})}]))};
  const result=await overview(client,{id:'u'});
  assert.equal(result.available,1000);assert.equal(result.balance,1000);
  results.push({test:'Negative pending values inflate computed balances (schema enforcement not simulated)',earnings:0,available:result.available,purchaseBalance:result.balance,confirmed:true});
}
{
  const source=read('base44/actors/LiveBroadcast/entry.ts').replace(/^import .*;\r?\n/gm,'').replace('export default class','class');
  const Live=vm.runInNewContext(source+'\nLiveBroadcast',{Actor:class{},console});
  const actor=new Live();const sent=[];const record={host_user_id:'banned-user',status:'ended'};let banReads=0;
  actor.storage={put:async()=>{}};actor.broadcast=()=>{};
  actor.client={asServiceRole:{entities:{LiveRoom:{get:async()=>record,update:async(id,data)=>Object.assign(record,data)},LiveBan:{filter:async()=>{banReads++;return [{user_id:'banned-user'}];}}}}};
  const conn={id:'conn',identity:{type:'authenticated',userId:'banned-user'},send:m=>sent.push(m)};
  await actor.handleConnect(conn);await actor.handleMessage(conn,{type:'host_start',registryId:'room'});
  assert.equal(record.status,'live');assert.equal(banReads,0);
  results.push({test:'Actor starts stream without consulting ban records',roomStatus:record.status,banQueries:banReads,confirmed:true});
}
{
  let llmCalls=0;
  const fn=handler('base44/functions/customerServiceReply/entry.ts',{createClientFromRequest:()=>({auth:{me:async()=>null},asServiceRole:{integrations:{Core:{InvokeLLM:async()=>{llmCalls++;return {reply:'mock'};}}}}})});
  assert.equal((await fn(request({history:[{from:'me',text:'hello'}]}))).status,200);
  assert.equal(llmCalls,1);
  results.push({test:'Customer service handler invokes paid integration without auth check (gateway not tested)',llmCalls,confirmed:true});
}
fs.writeFileSync('work/audit-repro-results.json',JSON.stringify(results,null,2));
console.log(JSON.stringify(results,null,2));
