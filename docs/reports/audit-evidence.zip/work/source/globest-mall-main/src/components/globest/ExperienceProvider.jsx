import React, { createContext, useContext, useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
const Context = createContext(null);
export const HBH_RATE = 0.1; // 1 HBH = S$0.10
export const SHOP_REWARD = 0.5; // HBH earned per S$1 spent
export const toHbh = sgd => Math.ceil(Number(sgd) / HBH_RATE);
const initial = { lang: 'zh', hbh: 0, solano: 0, cart: [], claims: [], board: [1,1,0,0,0,0,0,0,0], merges: 0, customers: [], orders: [], reminders: [], referral: '' };
export default function ExperienceProvider({ children }) {
  const [state, setState] = useState(() => ({ ...initial, ...JSON.parse(localStorage.getItem('globest-experience-v1') || '{}') }));
  const [notice, setNotice] = useState('');
  useEffect(() => { document.documentElement.lang = state.lang === 'zh' ? 'zh-CN' : 'en'; document.title = state.lang === 'zh' ? 'Globest Mall · 中华滋补，环球健康' : 'Globest Mall · Eastern Roots. Global Wellness.'; }, [state.lang]);
  useEffect(() => { base44.auth.isAuthenticated().then(ok => ok && base44.auth.me()).then(me => { if (!me?.hbh_bonus) return; const id = `bonus:${me.id}`; update(s => s.claims.includes(id) ? s : { ...s, hbh: s.hbh + me.hbh_bonus, claims: [...s.claims, id] }); }); }, []);
  const [authed, setAuthed] = useState(false);
  const today = () => new Date().toLocaleDateString('en-CA');
  const refresh = async () => { const { data } = await base44.functions.invoke('pointsLedger', { action: 'summary' }); update(s => ({ ...s, hbh: data.balance, claims: data.checkedIn && !s.claims.includes(`daily:${today()}`) ? [...s.claims, `daily:${today()}`] : s.claims })); };
  useEffect(() => { let off; base44.auth.isAuthenticated().then(ok => { if (!ok) return; setAuthed(true); refresh(); off = base44.entities.PointsLedger.subscribe(() => refresh()); }); return () => off?.(); }, []);
  const server = async (payload, okMsg) => { try { const { data } = await base44.functions.invoke('pointsLedger', payload); if (okMsg) notify(okMsg(data)); } catch (e) { const r = e.response?.data?.reason; notify(r === 'already_claimed' ? t('今日已领取', 'Already claimed today') : r === 'daily_cap' ? t('今日游戏奖励已达上限', 'Daily game cap reached') : r === 'insufficient' ? t('HBH 余额不足', 'Not enough HBH') : e.message); } refresh(); };
  const update = (fn) => setState(prev => { const next = typeof fn === 'function' ? fn(prev) : { ...prev, ...fn }; localStorage.setItem('globest-experience-v1', JSON.stringify(next)); return next; });
  const t = (zh, en) => state.lang === 'zh' ? zh : en;
  const notify = (text) => { setNotice(text); window.clearTimeout(window.globestNotice); window.globestNotice = window.setTimeout(() => setNotice(''), 3500); };
  const claim = (key, amount) => { const id = `${key}:${new Date().toLocaleDateString('en-CA')}`; if (state.claims.includes(id)) return false; if (authed) { update(s => ({ ...s, claims: [...s.claims, id] })); server(key === 'daily' ? { action: 'checkin' } : { action: 'earn', key }, d => t(`已获得 ${d.amount} HBH`, `Earned ${d.amount} HBH`)); return true; } update(s => s.claims.includes(id) ? s : ({ ...s, hbh: s.hbh + amount, claims: [...s.claims, id] })); notify(t(`已获得 ${amount} HBH 体验积分`, `Earned ${amount} demo HBH points`)); return true; };
  const claimed = key => state.claims.includes(`${key}:${new Date().toLocaleDateString('en-CA')}`);
  const addCart = (product) => { update(s => { const found = s.cart.find(p => p.id === product.id); return { ...s, cart: found ? s.cart.map(p => p.id === product.id ? { ...p, quantity: p.quantity + 1 } : p) : [...s.cart, { ...product, quantity: 1 }] }; }); notify(t('已加入购物车', 'Added to your cart')); };
  const spendHbh = (points, sgd) => { if (state.hbh < points) { notify(t('HBH 余额不足', 'Not enough HBH')); return false; } const back = Math.floor(sgd * SHOP_REWARD); if (authed) { update(s => ({ ...s, hbh: s.hbh - points })); server({ action: 'spend', points, sgd, ref: crypto.randomUUID() }, d => t(`已用 ${points} HBH 支付，购物奖励 +${d.back} HBH`, `Paid ${points} HBH, earned +${d.back} HBH`)); return true; } update(s => ({ ...s, hbh: s.hbh - points + back })); notify(t(`已用 ${points} HBH 支付，购物奖励 +${back} HBH`, `Paid ${points} HBH, earned +${back} HBH`)); return true; };
  const earnHbh = (amount, zh, en) => { if (authed) return server({ action: 'game', amount }, d => t(`${zh} +${d.amount} HBH`, `${en} +${d.amount} HBH`)); update(s => ({ ...s, hbh: s.hbh + amount })); notify(t(`${zh} +${amount} HBH`, `${en} +${amount} HBH`)); };
  const pick = p => ({ id: p.id, name_zh: p.name_zh, name_en: p.name_en, price: Number(p.price), image: p.image, quantity: p.quantity || 1 });
  const recordPurchase = (items, total) => update(s => ({ ...s, orders: [{ id: `GB${Date.now().toString().slice(-8)}`, date: new Date().toISOString(), items: items.map(pick), total: Number(total), paid: true }, ...s.orders] }));
  const toggleFavorite = p => { const on = (state.favorites || []).some(f => f.id === p.id); update(s => ({ ...s, favorites: on ? s.favorites.filter(f => f.id !== p.id) : [pick(p), ...(s.favorites || [])] })); notify(on ? t('已取消收藏', 'Removed from favorites') : t('已加入收藏', 'Added to favorites')); };
  return <Context.Provider value={{ state, update, t, claim, claimed, notify, addCart, spendHbh, earnHbh, recordPurchase, toggleFavorite }}>{children}{notice && <div role="status" className="notice">{notice}</div>}</Context.Provider>;
}
export const useExperience = () => useContext(Context);