import Stripe from 'npm:stripe@18.5.0';
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.48';
import { secrets } from 'base44:runtime';

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const stripe = new Stripe(secrets.get('STRIPE_SECRET_KEY'));
    const signature = req.headers.get('stripe-signature');
    if (!signature) return Response.json({ error: 'Missing signature' }, { status: 400 });
    const rawBody = await req.text();
    const event = await stripe.webhooks.constructEventAsync(rawBody, signature, secrets.get('STRIPE_WEBHOOK_SECRET'));
    if (event.type === 'checkout.session.completed') {
      const session = event.data.object;
      if (session.payment_status === 'paid' && session.metadata?.membership_tier) {
        const email = session.customer_details?.email;
        if (!email) throw new Error('Paid membership has no customer email');
        const fee = Number(session.metadata.membership_fee || 0);
        const existing = await base44.asServiceRole.entities.MemberProfile.filter({ email });
        const profile = {
          name: session.customer_details?.name || email.split('@')[0],
          email,
          tier: session.metadata.membership_tier,
          membership_fee: fee,
          points_balance: existing[0]?.points_balance || 0,
          payment_status: 'paid',
          stripe_customer_id: typeof session.customer === 'string' ? session.customer : '',
          stripe_session_id: session.id,
          joined_at: new Date().toISOString()
        };
        if (existing[0]) await base44.asServiceRole.entities.MemberProfile.update(existing[0].id, profile);
        else await base44.asServiceRole.entities.MemberProfile.create(profile);
      } else if (session.payment_status === 'paid' && !session.livemode && ['standard', 'vip'].includes(session.metadata?.package_tier)) {
        const tier = session.metadata.package_tier;
        const expected = tier === 'vip' ? 500000 : 150000;
        const expectedPrice = tier === 'vip' ? 'price_1UJaKuLfGbLosfGyvNZTfz2E' : 'price_1UJaKuLfGbLosfGyfNyiP6MZ';
        const lineItems = await stripe.checkout.sessions.listLineItems(session.id, { limit: 1 });
        if (session.currency !== 'sgd' || session.amount_total !== expected || lineItems.data[0]?.price?.id !== expectedPrice || lineItems.data[0]?.quantity !== 1) throw new Error('Unexpected package payment');
        const buyer = await base44.asServiceRole.entities.User.get(session.metadata.package_user_id);
        const email = session.customer_details?.email;
        if (!buyer || buyer.email?.toLowerCase() !== email?.toLowerCase()) throw new Error('Package buyer mismatch');
        const existing = await base44.asServiceRole.entities.MemberProfile.filter({ email });
        if (existing[0]?.stripe_session_id === session.id || existing[0]?.payment_status === 'paid') return Response.json({ received: true });
        const selectedTier = tier === 'vip' || existing[0]?.tier === 'vip' ? 'vip' : 'standard';
        const profile = { name: buyer.full_name || email.split('@')[0], email, tier: selectedTier, membership_fee: selectedTier === 'vip' ? 5000 : 1500, points_balance: existing[0]?.points_balance || 0, payment_status: 'test', stripe_customer_id: typeof session.customer === 'string' ? session.customer : '', stripe_session_id: session.id, joined_at: new Date().toISOString() };
        if (existing[0]) await base44.asServiceRole.entities.MemberProfile.update(existing[0].id, profile);
        else await base44.asServiceRole.entities.MemberProfile.create(profile);
      }
    }
    return Response.json({ received: true });
  } catch (error) {
    console.error('stripeMembershipWebhook', error);
    return Response.json({ error: error.message }, { status: 400 });
  }
}