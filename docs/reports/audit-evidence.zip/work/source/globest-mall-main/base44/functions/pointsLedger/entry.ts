import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';

const tierOf = (n) => n >= 5000 ? 'prestige' : n >= 1000 ? 'vip' : 'standard';
const sgtDay = () => new Date(Date.now() + 8 * 3600e3).toISOString().slice(0, 10);
const err = (reason, status = 400) => Response.json({ ok: false, reason }, { status });

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    const body = await req.json();
    const L = base44.asServiceRole.entities.PointsLedger;
    const balanceOf = async (uid) => (await L.aggregate({ query: { user_id: uid }, sum: ['amount'] })).rows?.[0]?.sum_amount || 0;
    const day = sgtDay();

    // Idempotent single-entry write: same idem_key can only exist once.
    const post = async (uid, amount, type, idem_key, note, counterparty) => {
      if (await L.count({ idem_key })) return false;
      const bal = await balanceOf(uid);
      await L.create({ user_id: uid, amount, type, idem_key, note, counterparty, balance_after: bal + amount });
      const dupes = (await L.filter({ idem_key }, { sort: 'created_date', limit: 10 })).items;
      for (const d of dupes.slice(1)) await L.delete(d.id);
      return true;
    };

    switch (body.action) {
      case 'checkin': {
        const ok = await post(user.id, 20, 'checkin', `checkin:${user.id}:${day}`, `Daily check-in ${day}`);
        return ok ? Response.json({ ok: true, amount: 20 }) : err('already_claimed', 409);
      }
      case 'earn': { // interaction rewards, once per key per day
        const key = String(body.key || '').slice(0, 80);
        if (!/^read-[\w-]+$/.test(key)) return err('invalid_key');
        const ok = await post(user.id, 10, 'interaction', `earn:${user.id}:${key}:${day}`, `Reading reward ${key}`);
        return ok ? Response.json({ ok: true, amount: 10 }) : err('already_claimed', 409);
      }
      case 'game': { // capped at 200 HBH per day
        const amount = Math.min(50, Math.max(1, Math.floor(Number(body.amount) || 0)));
        const today = (await L.aggregate({ query: { user_id: user.id, type: 'game', created_date: { $gte: `${day}T00:00:00+08:00` } }, sum: ['amount'] })).rows?.[0]?.sum_amount || 0;
        if (today + amount > 200) return err('daily_cap', 409);
        await post(user.id, amount, 'game', `game:${user.id}:${crypto.randomUUID()}`, 'Planting game reward');
        return Response.json({ ok: true, amount });
      }
      case 'spend': {
        const points = Math.floor(Number(body.points));
        const sgd = Number(body.sgd) || 0;
        const ref = String(body.ref || crypto.randomUUID());
        if (!(points > 0)) return err('invalid_amount');
        if ((await balanceOf(user.id)) < points) return err('insufficient', 409);
        const ok = await post(user.id, -points, 'redeem', `spend:${user.id}:${ref}`, `Paid with HBH S$${sgd}`);
        if (!ok) return err('duplicate', 409);
        const back = Math.floor(sgd * 0.5);
        if (back > 0) await post(user.id, back, 'purchase', `reward:${user.id}:${ref}`, 'Shopping reward');
        return Response.json({ ok: true, back });
      }
      case 'transfer': {
        const email = String(body.email || '').trim().toLowerCase();
        const amount = Math.floor(Number(body.amount));
        const ref = String(body.ref || '');
        if (!ref || !(amount > 0) || amount > 1000000) return err('invalid_amount');
        if (email === user.email?.toLowerCase()) return err('self_transfer');
        const to = (await base44.asServiceRole.entities.User.filter({ email }))[0];
        if (!to) return err('recipient_not_found', 404);
        if ((await balanceOf(user.id)) < amount) return err('insufficient', 409);
        const ok = await post(user.id, -amount, 'transfer_out', `xfer-out:${ref}`, `Transfer to ${email}`, to.id);
        if (!ok) return err('duplicate', 409);
        if ((await balanceOf(user.id)) < 0) { // concurrent overspend → roll back
          await post(user.id, amount, 'adjust', `xfer-rollback:${ref}`, 'Transfer reversed');
          return err('insufficient', 409);
        }
        await post(to.id, amount, 'transfer_in', `xfer-in:${ref}`, `Transfer from ${user.email}`, user.id);
        return Response.json({ ok: true, to: to.full_name || email });
      }
      default: {
        const [balance, lifeRows, checkedIn] = await Promise.all([
          balanceOf(user.id),
          L.aggregate({ query: { user_id: user.id, amount: { $gt: 0 }, type: { $nin: ['transfer_in', 'adjust'] } }, sum: ['amount'] }),
          L.count({ idem_key: `checkin:${user.id}:${day}` }),
        ]);
        const lifetime = lifeRows.rows?.[0]?.sum_amount || 0;
        return Response.json({ balance, lifetime, tier: tierOf(lifetime), checkedIn: checkedIn > 0, sgd_value: balance * 0.1 });
      }
    }
  } catch (error) {
    console.error(error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}